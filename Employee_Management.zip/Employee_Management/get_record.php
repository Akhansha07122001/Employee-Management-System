<?php

include 'connect.php'; 


if(isset($_POST['checking_edit']))
{
    $id = $_POST['id'];
    

    $result_array = array();
    $query = "SELECT * FROM emloyees WHERE id='$id' ";
    $query_run = mysqli_query($conn, $query);

    
    if(mysqli_num_rows($query_run) > 0)
    {
       
        foreach($query_run as $row)
        {
            array_push($result_array, $row);
        }
        
        header('Content-type: application/json');
        echo json_encode($result_array);
    }
    else
    {
       
        echo $return = "No Record Found.!";
    }


}


if(isset($_POST['update_button']))
{
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $position = $_POST['position'];

    $update_query = "update emloyees set firstname='$fname',lastname='$lname',email='$email',phone='$phone',position='$position' where id='$id'";
    $query = mysqli_query($conn,$update_query);

    if($query){
        echo $result = "Updated!!";
    }else{
        echo $result = " Not Updated!!";
    }
}

?>