$(document).ready(function(){

    function show_data(){
        $.ajax({
            url: "display_table.php",
            method: "GET",
            success: function (response) {
                $("#show_table").empty();
                var tab = "";
                 $.each(response,function(key,value){
                        tab += '<tr>';
                        tab += '<td>'+value.id+'</td>';
                        tab += '<td><img src="upload_img/' + value.profile_picture + '" alt="Employee Photo" width="60" height="50" class="rounded-circle"></td>';
                        tab += '<td>'+value.firstname+'</td>';
                        tab += '<td>'+value.lastname+'</td>';
                        tab += '<td>'+value.email+'</td>';
                        tab += '<td>'+value.phone+'</td>';
                        tab += '<td>'+value.position+'</td>';
                        tab += '<td>';
                        tab += '<button type="button" id="del_btn" class="btn btn-danger fw-bold" data-id="' + value.id + '">Delete</button>';
                        tab += '<button type="button" id="up_btn" class="btn btn-warning ms-2 fw-bold" data-bs-toggle="modal" data-bs-target="#crud_update" data-id="' + value.id + '">Update</button>';
                        tab += '</td>';
                        tab += '</tr>';
                    });
                     
                    $("#show_table").append(tab);
            },
            error: function () {
                alert("Something went wrong");
            }
        });
    }
    
  show_data();

  //update

  $('#show_table').on('click', '#up_btn', function () {
    let id = $(this).attr('data-id');
    console.log(id);
    
    $.ajax({
        url: "get_record.php",
        method: "POST",
        data: { 
            'checking_edit': true,
            'id': id 
        },
        success: function(response) {
            console.log(response);
            if(response.length > 0) {
                $.each(response, function (key, emp) { 

                    $('#id_edit').val(emp['id']);
                    $('#edit_fname').val(emp['firstname']);
                    $('#edit_lname').val(emp['lastname']);
                    $('#edit_email').val(emp['email']);
                    $('#edit_phone').val(emp['phone']);
                    $('#edit_position').val(emp['position']);
                });
                $('#crud_update').modal('show');
            } else {
                alert('No record found');
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
            alert('Error fetching data. Please try again.');
        }
    });


});


$('#up_btn').click(function() {
    var id = $('#id_edit').val();
    var fname = $('#edit_fname').val();
    var lname = $('#edit_lname').val();
    var email = $('#edit_email').val();
    var phone = $('#edit_phone').val();
    var position = $('#edit_position').val();

    // Validate the input fields
    if (fname === '' || lname === '' || email === '' || phone === '' || position === '') {
        alert("Please fill all the details..");
        return;
    }

   
    $.ajax({
        url: "get_record.php",
        method: "POST",
        data: {
            'update_button': true,
            'id': id,
            'fname': fname,
            'lname': lname,
            'email': email,
            'phone': phone,
            'position': position
        },
        success: function(response) {
            if (response) {
                
                $('#crud_update').modal('hide');
                $('#show_table').html("");
                show_data();
            } else {
                alert('Failed to update record: ' + response);
            }
        },
        error: function(xhr, status, error) {
            console.error(error);
            alert('Error updating record. Please try again later.');
        }
    });
});


//delete

$('#show_table').on('click', '#del_btn', function () {
    let id = $(this).attr('data-id');
    console.log(id);
    let confirmed = confirm('Are you sure you want to delete this item?');

    if (confirmed) {
        console.log('Item ID to delete:', id);


        $.ajax({
            url: 'delete.php', 
            type: 'POST',
            data: { 'id': id },
            success: function(response) {
                alert('Item deleted successfully');
                $('#item-' + id).remove(); 
                show_data();
            },
            error: function(xhr, status, error) {
                // Handle error
                console.error('Error deleting item:', error);
            }
        });
    } else {
        alert('Deletion canceled');
    }







    

});













});
