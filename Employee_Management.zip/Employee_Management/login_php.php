<?php
session_start();
include 'connect.php';

if(isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    
    $stmt = $conn->prepare("SELECT * FROM sign_up WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if(password_verify($password, $row['password'])) {
            $fname = $row["firstname"];
            $lname = $row["lastname"];
            $id = $row["id"];
       $_SESSION["fname"] = $fname;
       $_SESSION["lname"] = $lname;
            header("Location: index.php"); 
            exit;
        } else {
            $_SESSION['err_msg'] = "Incorrect email or password.";
            header("Location: login.php");
            exit;
        }
    } else {
        $_SESSION['err_msg'] = "User not found.";
        header("Location: login.php");
        exit;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();

header("Location: login.php");
exit;
?>
