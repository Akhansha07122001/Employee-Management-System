<?php
include 'connect.php';
session_start();
?>
<!doctype html>
<html>
<head>
    <title>Index</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" 
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        
    <style>
        .modal-header {
            display: flex;
            font-weight: bold;
            background: #FFEBCD;
        }
        .modal-footer {
            background: #FFEBCD;
        }
        .modal-body {
            background: #F0F8FF;
        }

         body{
            
         background-image: url('img/img4.jpg');
        background-repeat: no-repeat;
         background-attachment: fixed;
           background-size: cover;
            
         }




    </style>
</head>
<body>
<div class="container-fluid">
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand">Employee Management System</a>
            <span class="d-flex">
                <p class="fw-bold px-3 pt-2">Welcome, <?php echo htmlspecialchars($_SESSION['fname']); ?></p>
                <a type="button" class="btn btn-info fw-bold" href="logout.php">Logout</a>
            </span>
        </div>
    </nav>

    <div class="py-5">
        <div class="d-grid d-md-flex justify-content-md-end py-2">
            <button type="button" class="btn rounded-4 fw-bold" data-bs-toggle="modal" data-bs-target="#add" style="background-color:#FFE4B5;">
                Add Employee
            </button>
        </div>

        <?php
        if (isset($_SESSION['msg'])) {
            echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($_SESSION['msg']) . '</div>';
            unset($_SESSION['msg']);
        }

        if (isset($_SESSION['up_msg'])) {
            echo '<div class="alert alert-success" role="alert">' . htmlspecialchars($_SESSION['up_msg']) . '</div>';
            unset($_SESSION['up_msg']);
        }
        ?>

        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="add_emp" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="add_emp">Add Employee</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="add_php.php" enctype="multipart/form-data">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control rounded-4" id="floatingInput" placeholder="fname" name="fname" required>
                                <label for="floatingInput">First Name</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control rounded-4" id="floatingInput" placeholder="lname" name="lname" required>
                                <label for="floatingInput">Last Name</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="email" class="form-control rounded-4" id="floatingInput" placeholder="email" name="email" required>
                                <label for="floatingInput">Email</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control rounded-4" id="floatingInput" placeholder="phone" name="phone" required>
                                <label for="floatingInput">Phone</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control rounded-4" id="floatingInput" placeholder="position" name="position" required>
                                <label for="floatingInput">Position</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="file" class="form-control rounded-4" id="floatingInput" placeholder="file" name="photo" required>
                                <label for="floatingInput">Photo Upload</label>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                        <input type="submit" class="btn btn-success" value="Add" name="add_emp">
                    </div>
                    </form>
                </div>
            </div>
        </div>

        
                <table class="table table-hover" style="">
                    <thead style="text-align: center;" class="table-info">
                    <tr>
                        <th>Id</th>
                        <th>Photo</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Position</th>
                        <th>Action</th>
                        
                    </tr>
                    </thead>
                    <tbody id="show_table" style="text-align: center;">
                    </tbody>
                </table>
            </div>
        
  
    <div class="modal fade" id="crud_update" tabindex="-1" aria-labelledby="up_emp" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="up_emp">Update Employee</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                    <input type="hidden" id="id_edit">
                        
                        <form method="post" action="" enctype="multipart/form-data">
                            

                        <div class="input-group mb-3">
  <span class="input-group-text rounded-4" id="inputGroup-sizing-default">First Name</span>
  <input type="text" class="form-control rounded-4" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="edit_fname">
</div>

<div class="input-group mb-3">
  <span class="input-group-text rounded-4" id="inputGroup-sizing-default">Last Name</span>
  <input type="text" class="form-control rounded-4" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="edit_lname">
</div>

<div class="input-group mb-3">
  <span class="input-group-text rounded-4" id="inputGroup-sizing-default">Email</span>
  <input type="email" class="form-control rounded-4" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="edit_email">
</div>

<div class="input-group mb-3">
  <span class="input-group-text rounded-4" id="inputGroup-sizing-default">Phone</span>
  <input type="text" class="form-control rounded-4" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="edit_phone">
</div>

<div class="input-group mb-3">
  <span class="input-group-text rounded-4" id="inputGroup-sizing-default">Position</span>
  <input type="text" class="form-control rounded-4" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" id="edit_position">
</div>
              
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                        <input type="submit" class="btn btn-success" value="Update" id="up_btn">
                    </div>
                    </form>
                </div>
            </div>
        </div>


















</div>
<script src="script.js"></script>
</body>
</html>
