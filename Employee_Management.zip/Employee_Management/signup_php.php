<?php

session_start();
include 'connect.php';

if (isset($_POST['register'])) {

    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    
    if (empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm_password)) {
        $_SESSION['err_msg'] = "All fields are required.";
        header("Location: sign_up.php");
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['err_msg'] = "Invalid email format.";
        header("Location: sign_up.php");
        exit;
    }

    if ($password !== $confirm_password) {
        $_SESSION['err_msg'] = "Passwords do not match.";
        header("Location: sign_up.php");
        exit;
    }

    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    
    $stmt = $conn->prepare("INSERT INTO sign_up (firstname, lastname, email, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $first_name, $last_name, $email, $hashed_password);

    
    if ($stmt->execute()) {
        $_SESSION['success_msg'] = "Registration successful.";
       header("Location: sign_up.php");
    } else {
        $_SESSION['err_msg'] = "Registration failed. Please try again.";
        header("Location: sign_up.php");
    }

    
    $stmt->close();
}


$conn->close();

?>
