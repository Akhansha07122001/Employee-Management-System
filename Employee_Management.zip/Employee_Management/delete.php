<?php 
include 'connect.php'; 

if(isset($_POST['id'])){

    $id = $_POST['id'];

    $query = "delete from emloyees where id='$id'";
    $result = mysqli_query($conn, $query);
    if($result) {
        echo $result = 'Deleted.';
    }else{
        echo $result = 'Something went wrong.';
    }
}
mysqli_close($conn);
?>
