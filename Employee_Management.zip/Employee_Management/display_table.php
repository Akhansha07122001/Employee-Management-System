<?php 
include 'connect.php'; 
session_start();

$query = "select * from emloyees";
$data = mysqli_query($conn,$query);
$total = mysqli_num_rows($data);
$result = [];


if($total != 0){
    foreach($data as $rows){
        array_push($result,$rows);
    }
    header('Content-type:application/json');
    echo json_encode($result);
   
}else{
    $_SESSION['err'] = "Table do not have records.";
}
mysqli_close($conn);
?>
