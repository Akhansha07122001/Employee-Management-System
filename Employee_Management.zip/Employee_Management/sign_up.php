<?php
   include ('connect.php');
   session_start();
?>
<!doctype html>
<html>
    <head>
        <title>Sign-up</title>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" 
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
         integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

         <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <body>
    <?php
    if (isset($_SESSION['err_msg'])) {
        echo "<script>
        Swal.fire({
            title: 'Error!',
            text: '".$_SESSION['err_msg']."',
            icon: 'error'
        });
        </script>";
        unset($_SESSION['err_msg']);
    }
    if (isset($_SESSION['success_msg'])) {
        echo "<script>
        Swal.fire({
            title: 'Success!',
            text: '".$_SESSION['success_msg']."',
            icon: 'success',
            footer: '<a href=\"login.php\" style=\"text-decoration:none; font-size:20px;\">Login Now</a>'
        });
        </script>";
        unset($_SESSION['success_msg']);
    }
    ?>
        
    <section class="vh-100" style="background-color: #eee;">
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;">
          <div class="card-body p-md-5">
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Sign up</p>

                <form class="mx-1 mx-md-4" method="post" action="signup_php.php">

                <div class="form-floating mb-3">
           <input type="text" class="form-control" id="floatingInput" placeholder="first_name" name="first_name">
           <label for="floatingInput">First Name</label>
            </div>

            <div class="form-floating mb-3">
           <input type="text" class="form-control" id="floatingInput" placeholder="last_name" name="last_name">
           <label for="floatingInput">Last Name</label>
            </div>

            <div class="form-floating mb-3">
           <input type="email" class="form-control" id="floatingInput" placeholder="email" name="email">
           <label for="floatingInput">Email</label>
            </div>

            <div class="form-floating mb-3">
           <input type="password" class="form-control" id="floatingInput" placeholder="password" name="password">
           <label for="floatingInput">Password</label>
            </div>

            <div class="form-floating mb-3">
           <input type="password" class="form-control" id="floatingInput" placeholder="password" name="confirm_password">
           <label for="floatingInput">Confirm Password</label>
            </div>

            <div class="form-check d-flex justify-content-center mb-5">
                   
                   <p class="px-2">Have Account</p><a href="login.php" style="text-decoration:none;" class="link-primary fw-bold">Login here</a>
                    
               </div>

                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
            <input type="submit" type="button" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-lg" value="Sign up" name="register">
                  </div>
                  
                </form>

              </div>
              <div class="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">

                <img src="img/img1.jpg"
                  class="img-fluid" alt="Sample image">

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

        
  
    </body>
    </html>